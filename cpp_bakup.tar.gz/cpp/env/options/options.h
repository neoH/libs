// ******************************************************************************************
// File         : options.h
// Author       : Ryan
// Creating Date: Tue Aug 27 10:16:14 2019
// Claim        : only the author can comment without a signature preffixed by ', that
// means anyone else want to change the code must comments with '.
// ******************************************************************************************
//

#ifndef options__h
#define options__h


#endif /* options__h */
